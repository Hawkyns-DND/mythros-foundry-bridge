/**
 * MythrOS Foundry Bridge — relay + sync + combat augmentation (client/GM-browser side).
 *
 * Phase A combat augmentation (this build): hidden monster HP, async turn-prep
 * declarations, and permadeath, layered on the dnd5e engine (Foundry-local; Phase B
 * wires these two-way to Discord).
 *
 * Mirrors chat + dice rolls between this Foundry world and the MythrOS Discord
 * session in BOTH directions:
 *
 *   Foundry → Discord : the `createChatMessage` hook POSTs each public message to
 *                       the MythrOS web app (`/api/v1/foundry/relay`).
 *   Discord → Foundry : a WebSocket to `/api/v1/foundry/socket` receives Discord
 *                       chat and creates a matching ChatMessage here.
 *
 * Echo-loop guards:
 *   - Messages we inject from Discord carry `flags.mythros.relayed = true`; the
 *     outbound hook skips anything carrying it.
 *   - Only the PRIMARY active GM relays/injects, so N open clients don't multiply
 *     a single message into N copies.
 *
 * Privacy: GM whispers / blind / self rolls (anything with a whisper target or the
 * blind flag) are never sent to Discord. The server also re-checks roll_mode.
 */

const MOD = "mythros-foundry-bridge";

function S(key) {
  return game.settings.get(MOD, key);
}

/** Only the one canonical active GM acts, so relays/injections aren't duplicated. */
function isPrimaryGM() {
  return game.user?.isGM && game.users?.activeGM?.id === game.user?.id;
}

/** Strip HTML to a plain single line for Discord. */
function toPlainText(html) {
  if (!html) return "";
  const tmp = document.createElement("div");
  tmp.innerHTML = html;
  return (tmp.textContent || tmp.innerText || "").replace(/\s+/g, " ").trim();
}

// ── Settings ────────────────────────────────────────────────────────────────
Hooks.once("init", () => {
  game.settings.register(MOD, "webBaseUrl", {
    name: "MythrOS web base URL",
    hint: "e.g. https://kottrpg.com — the MythrOS web app that fronts the relay.",
    scope: "world", config: true, type: String, default: "https://kottrpg.com",
  });
  game.settings.register(MOD, "sharedSecret", {
    name: "Bridge shared secret",
    hint: "Must equal FOUNDRY_BRIDGE_SECRET on the bot/web. Keep it private.",
    scope: "world", config: true, type: String, default: "",
  });
  game.settings.register(MOD, "gmDiscordId", {
    name: "GM Discord user ID",
    hint: "The Discord user id of the GM running sessions. Routes relays to that GM's live session channel.",
    scope: "world", config: true, type: String, default: "",
  });
  game.settings.register(MOD, "relayEnabled", {
    name: "Enable relay",
    hint: "Master switch for both directions.",
    scope: "world", config: true, type: Boolean, default: true,
  });
  game.settings.register(MOD, "relayRolls", {
    name: "Relay dice rolls",
    scope: "world", config: true, type: Boolean, default: true,
  });
  game.settings.register(MOD, "relayChat", {
    name: "Relay chat messages",
    scope: "world", config: true, type: Boolean, default: true,
  });
  game.settings.register(MOD, "syncEconomy", {
    name: "Sync economy from MythrOS",
    hint: "On session start, pull each bridged actor's gold from MythrOS (the economy authority).",
    scope: "world", config: true, type: Boolean, default: true,
  });
  game.settings.register(MOD, "combatModule", {
    name: "MythrOS combat augmentation",
    hint: "Layer the MythrOS combat feel on dnd5e: hidden monster HP, turn-prep declarations, and permadeath. Master switch for the combat features.",
    scope: "world", config: true, type: Boolean, default: true,
  });
  game.settings.register(MOD, "hideNpcHp", {
    name: "Hide monster HP from players",
    hint: "When a combat starts, set non-PC token bars to GM-only so players can't read monster HP.",
    scope: "world", config: true, type: Boolean, default: true,
  });
});

// ── Phase 2 live sync ─────────────────────────────────────────────────────────
// Combat state (HP / temp / death saves) is pushed Foundry → MythrOS as it changes;
// economy (gold) is pulled MythrOS → Foundry on session start. Only the primary GM
// acts, and only for actors carrying flags.mythros.characterId.

// Foundry → MythrOS: HP / death-save changes.
Hooks.on("updateActor", async (actor, changes) => {
  try {
    if (!S("relayEnabled") || !isPrimaryGM()) return;
    const cid = actor.flags?.mythros?.characterId;
    if (!cid) return;
    // Only push when an HP or death-save field actually changed.
    const hpChanged = changes.system?.attributes?.hp !== undefined;
    const deathChanged = changes.system?.attributes?.death !== undefined;
    if (!hpChanged && !deathChanged) return;

    const secret = S("sharedSecret");
    const base = (S("webBaseUrl") || "").replace(/\/+$/, "");
    if (!secret || !base) return;

    const attrs = actor.system?.attributes || {};
    await fetch(`${base}/api/v1/foundry/sync`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${secret}` },
      body: JSON.stringify({
        character_id: Number(cid),
        hp_current: attrs.hp?.value ?? null,
        hp_temp: attrs.hp?.temp ?? null,
        death_successes: attrs.death?.success ?? null,
        death_failures: attrs.death?.failure ?? null,
      }),
    });
  } catch (err) {
    console.warn(`${MOD} | combat sync (Foundry→MythrOS) failed`, err);
  }
});

// MythrOS → Foundry: pull authoritative gold for every bridged actor on session start.
async function pullEconomy() {
  if (!isPrimaryGM() || !S("syncEconomy")) return;
  const secret = S("sharedSecret");
  const base = (S("webBaseUrl") || "").replace(/\/+$/, "");
  if (!secret || !base) return;
  for (const actor of game.actors) {
    const cid = actor.flags?.mythros?.characterId;
    if (!cid) continue;
    try {
      const res = await fetch(`${base}/api/v1/foundry/actor/${Number(cid)}`, {
        headers: { "Authorization": `Bearer ${secret}` },
      });
      if (!res.ok) continue;
      const data = await res.json();
      const gp = data?.system?.currency?.gp;
      // Setting currency fires updateActor, but our hook above only pushes on
      // HP/death changes, so this never loops back into a sync.
      if (typeof gp === "number" && gp !== actor.system?.currency?.gp) {
        await actor.update({ "system.currency.gp": gp });
      }
    } catch (err) {
      console.warn(`${MOD} | economy pull failed for actor`, cid, err);
    }
  }
}
Hooks.once("ready", () => { if (game.user?.isGM) pullEconomy(); });

// ── Phase A — MythrOS combat augmentation ──────────────────────────────────────
// Hidden monster HP, async turn-prep declarations, and permadeath, layered on the
// dnd5e engine. Foundry-local in Phase A; Phase B syncs these to Discord.

const DEATH_FAILS_FATAL = 3;

function combatEnabled() {
  return S("combatModule");
}

/** Hide non-PC token HP bars from players when a combat begins (primary GM only). */
async function hideMonsterHp(combat) {
  if (!combatEnabled() || !S("hideNpcHp") || !isPrimaryGM()) return;
  const ownerOnly = CONST.TOKEN_DISPLAY_MODES.OWNER;
  for (const c of combat?.combatants ?? []) {
    const token = c.token;   // TokenDocument
    const actor = c.actor;
    if (!token || !actor || actor.type === "character") continue;
    if (token.displayBars === ownerOnly) continue;
    try { await token.update({ displayBars: ownerOnly }); } catch (e) { /* best-effort */ }
  }
}

Hooks.on("combatStart", (combat) => hideMonsterHp(combat));
Hooks.on("createCombat", (combat) => hideMonsterHp(combat));

// Turn-prep: when the active turn lands on a PC you own, prompt a declaration.
let _lastPrepKey = null;
Hooks.on("updateCombat", async (combat, changes) => {
  try {
    if (!combatEnabled()) return;
    if (changes.turn === undefined && changes.round === undefined) return;
    const c = combat.combatant;
    const actor = c?.actor;
    if (!actor || actor.type !== "character" || !actor.isOwner) return;
    if (game.user.isGM) return; // players declare; the GM runs the table
    const key = `${combat.id}:${combat.round}:${combat.turn}`;
    if (_lastPrepKey === key) return; // one prompt per turn
    _lastPrepKey = key;
    await promptTurnPrep(combat, c);
  } catch (err) {
    console.warn(`${MOD} | turn-prep prompt failed`, err);
  }
});

async function promptTurnPrep(combat, combatant) {
  const field = (name, label, ph) =>
    `<div class="form-group"><label>${label}</label><input type="text" name="${name}" placeholder="${ph}"/></div>`;
  const content = `
    <p>It's <strong>${combatant.name}</strong>'s turn. Declare your intent (optional):</p>
    ${field("movement", "Movement", "where you move")}
    ${field("action", "Action", "attack / cast / dash …")}
    ${field("bonus_action", "Bonus action", "off-hand / spell …")}
    ${field("target", "Target", "who / what")}
    ${field("notes", "Notes", "anything else")}`;
  const prep = await foundry.applications.api.DialogV2.prompt({
    window: { title: "Declare your turn", icon: "fa-solid fa-clipboard-list" },
    content,
    ok: { label: "Declare", callback: (_e, btn) => {
      const f = btn.form;
      return {
        movement: f.movement.value.trim(),
        action: f.action.value.trim(),
        bonus_action: f.bonus_action.value.trim(),
        target: f.target.value.trim(),
        notes: f.notes.value.trim(),
      };
    } },
  }).catch(() => null);
  if (!prep) return;
  try { await combatant.setFlag(MOD, "turnPrep", prep); } catch (e) { /* best-effort */ }
  const lines = [
    prep.movement && `<strong>Move:</strong> ${prep.movement}`,
    prep.action && `<strong>Action:</strong> ${prep.action}`,
    prep.bonus_action && `<strong>Bonus:</strong> ${prep.bonus_action}`,
    prep.target && `<strong>Target:</strong> ${prep.target}`,
    prep.notes && `<strong>Notes:</strong> ${prep.notes}`,
  ].filter(Boolean);
  if (!lines.length) return;
  await ChatMessage.create({
    speaker: { alias: `${combatant.name} — turn declaration` },
    content: `<div class="mythros-turn-prep">${lines.join("<br>")}</div>`,
  });
}

// Permadeath: a bridged PC at 3 death-save failures is locked dead (Foundry-local in A).
Hooks.on("updateActor", async (actor, changes) => {
  try {
    if (!combatEnabled() || !isPrimaryGM()) return;
    if (changes.system?.attributes?.death === undefined) return;
    if (actor.type !== "character") return;
    const fails = actor.system?.attributes?.death?.failure ?? 0;
    if (fails < DEATH_FAILS_FATAL) return;
    if (actor.getFlag(MOD, "permadead")) return; // already handled
    await actor.setFlag(MOD, "permadead", true);
    try { await actor.toggleStatusEffect?.("dead", { active: true, overlay: true }); } catch (e) { /* best-effort */ }
    await ChatMessage.create({
      speaker: { alias: "The Ash Remembers" },
      content: `<div class="mythros-permadeath"><h3>☠️ ${actor.name} has fallen.</h3><p>Three death-save failures. The Ash takes them — this death is permanent.</p></div>`,
    });
  } catch (err) {
    console.warn(`${MOD} | permadeath lock failed`, err);
  }
});

// ── Foundry → Discord ─────────────────────────────────────────────────────────
Hooks.on("createChatMessage", async (message) => {
  try {
    if (!S("relayEnabled") || !isPrimaryGM()) return;
    // Skip anything we ourselves injected from Discord (loop guard).
    if (message.flags?.mythros?.relayed) return;

    const isRoll = (message.rolls?.length ?? 0) > 0 || message.isRoll;
    if (isRoll && !S("relayRolls")) return;
    if (!isRoll && !S("relayChat")) return;

    // Privacy: never leak GM whispers / blind / self rolls into the player channel.
    const isPrivate = !!message.blind || (message.whisper?.length ?? 0) > 0;
    if (isPrivate) return;

    const secret = S("sharedSecret");
    const gmId = S("gmDiscordId");
    const base = (S("webBaseUrl") || "").replace(/\/+$/, "");
    if (!secret || !gmId || !base) return;

    const speaker = message.alias || message.speaker?.alias || "Unknown";
    const body = {
      gm_id: Number(gmId),
      speaker,
      content: toPlainText(message.content),
      is_roll: !!isRoll,
      roll_total: isRoll ? (message.rolls?.[0]?.total ?? null) : null,
      flavor: toPlainText(message.flavor || ""),
      roll_mode: isPrivate ? "gmroll" : null,
      scene: canvas?.scene?.name || null,
    };

    await fetch(`${base}/api/v1/foundry/relay`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${secret}`,
      },
      body: JSON.stringify(body),
    });
  } catch (err) {
    console.warn(`${MOD} | Foundry→Discord relay failed`, err);
  }
});

// ── Account bridge: provisioning ops (executed by the primary GM client) ───────
// MythrOS web sends {id, op, args}; we run the Foundry-side change and reply.
// Accounts are created PASSWORDLESS — the member sets their password on first login.
async function handleProvisionOp(op, args) {
  switch (op) {
    case "ensure_user": {
      const name = String(args.login || "Adventurer");
      let user = (game.users.getName?.(name)) || game.users.find((u) => u.name === name);
      if (!user) user = await User.create({ name, role: args.role ?? 1, password: "" });
      return { userId: user.id };
    }
    case "create_actor": {
      const actorData = foundry.utils.duplicate(args.actor || {});
      if (args.owner) {
        actorData.ownership = Object.assign(actorData.ownership || {}, { [args.owner]: 3 }); // 3 = OWNER
      }
      const actor = await Actor.create(actorData);
      return { actorId: actor.id };
    }
    case "reset_password": {
      const u = game.users.get(args.userId);
      if (u) await u.update({ password: "" }); // cleared → member sets it on next login
      return {};
    }
    case "set_role": {
      const u = game.users.get(args.userId);
      if (u) await u.update({ role: args.role });
      return {};
    }
    default:
      throw new Error(`unknown op: ${op}`);
  }
}

// ── Discord → Foundry (WebSocket) ──────────────────────────────────────────────
let _ws = null;
let _reconnectTimer = null;

function connectSocket() {
  if (!isPrimaryGM() || !S("relayEnabled")) return;
  const secret = S("sharedSecret");
  const gmId = S("gmDiscordId");
  const base = (S("webBaseUrl") || "").replace(/\/+$/, "");
  if (!secret || !gmId || !base) return;

  const wsBase = base.replace(/^http/, "ws");
  const url = `${wsBase}/api/v1/foundry/socket?secret=${encodeURIComponent(secret)}&gm=${encodeURIComponent(gmId)}`;

  try {
    _ws = new WebSocket(url);
  } catch (err) {
    console.warn(`${MOD} | socket open failed`, err);
    scheduleReconnect();
    return;
  }

  _ws.addEventListener("open", () => console.log(`${MOD} | bridge socket connected`));
  _ws.addEventListener("close", scheduleReconnect);
  _ws.addEventListener("error", () => { try { _ws.close(); } catch (e) {} });
  _ws.addEventListener("message", async (ev) => {
    try {
      const data = JSON.parse(ev.data);

      // Account-bridge provisioning op: {id, op, args} → reply {id, ok, result|error}.
      // Rides the same socket as relay; only the canonical GM (with create rights) acts.
      if (data.op) {
        if (!isPrimaryGM()) return;
        let reply;
        try {
          reply = { id: data.id, ok: true, result: await handleProvisionOp(data.op, data.args || {}) };
        } catch (e) {
          reply = { id: data.id, ok: false, error: String(e?.message || e) };
        }
        try { _ws.send(JSON.stringify(reply)); } catch (e) {}
        return;
      }

      if (data.origin !== "discord") return;
      if (!isPrimaryGM()) return; // only the canonical GM injects, once
      const speaker = (data.speaker || "Discord").slice(0, 80);
      // flags.mythros.relayed → the outbound hook will skip this, no bounce-back.
      await ChatMessage.create({
        content: foundry.utils.escapeHTML ? foundry.utils.escapeHTML(data.content || "") : (data.content || ""),
        speaker: { alias: `${speaker} (Discord)` },
        flags: { mythros: { relayed: true } },
      });
    } catch (err) {
      console.warn(`${MOD} | Discord→Foundry inject failed`, err);
    }
  });
}

function scheduleReconnect() {
  if (_reconnectTimer) return;
  _reconnectTimer = setTimeout(() => {
    _reconnectTimer = null;
    connectSocket();
  }, 5000);
}

Hooks.once("ready", () => {
  if (game.user?.isGM) connectSocket();
});
